//Creado con Ardora - www.webardora.net
//bajo licencia Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)
//para otros usos contacte con el autor
var timeAct=360; timeIni=360; timeBon=0;
var successes=0; successesMax=3; attempts=0; attemptsMax=1;
var score=0; scoreMax=1; scoreInc=1; scoreDec=1
var typeGame=0;
var tiTime=false;
var tiTimeType=0;
var tiButtonTime=true;
var textButtonTime="Comenzar";
var tiSuccesses=false;
var tiAttempts=false;
var tiScore=false;
var startTime;
var colorBack="#FFFDFD"; colorButton="#91962F"; colorText="#000000"; colorSele="#FF8000";colorLeave="#000000";
var goURLNext=false; goURLRepeat=false;tiAval=false;
var scoOk=0; scoWrong=0; scoOkDo=0; scoWrongDo=0; scoMessage=""; scoPtos=10;
var fMenssage="Verdana, Geneva, sans-serif";
var fActi="Verdana, Geneva, sans-serif";
var fEnun="Verdana, Geneva, sans-serif";
var timeOnMessage=5; messageOk="Correcto"; messageTime=""; messageError="Mal"; messageErrorG="Mal"; messageAttempts=""; isShowMessage=false;
var urlOk=""; urlTime=""; urlError=""; urlAttempts="";
var goURLOk="_blank"; goURLTime="_blank"; goURLAttempts="_blank"; goURLError="_blank"; 
borderOk="#008000"; borderTime="#FF0000";borderError="#FF0000"; borderAttempts="#FF0000";
var wordsGame="MS4x"; wordsStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
function giveZindex(typeElement){var valueZindex=0; capas=document.getElementsByTagName(typeElement);
for (i=0;i<capas.length;i++){if (parseInt($(capas[i]).css("z-index"),10)>valueZindex){valueZindex=parseInt($(capas[i]).css("z-index"),10);}}return valueZindex;}
var joinPar=[["QWxmYWJldG9z", "RXMgdW4gY29uanVudG8gZmluaXRvIG5vIHZhY8OtbyBkZSBzw61tYm9sb3M="],["Q2FkZW5hcw==", "RXMgdW5hIHNlY3VlbmNpYSBmaW5pdGEgZGUgc8OtbWJvbG9zIHF1ZSBwZXJ0ZW5lY2VuIGEgdW4gYWxmYWJldG8="],["TGVuZ3VhamVz", "RXMgdW4gY29uanVudG8gZGUgY2FkZW5hcyBzb2JyZSB1biBhbGZhYmV0byBkZWZpbmlkbw=="]];
var c=[[9,42],[7,64],[9,52]];
var con1=["Alfabetos","Cadenas","Lenguajes"];
var con2=["Es un conjunto finito no vacío de símbolos","Es una secuencia finita de símbolos que pertenecen a un alfabeto","Es un conjunto de cadenas sobre un alfabeto definido"];
var sel1=""; join1=[]; join2=[];
